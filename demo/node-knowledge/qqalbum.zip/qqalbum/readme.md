# QQ空间相册爬取器

config.js

> 配置QQ相关数据

安装环境

```
npm install
```

爬取数据
```
node index_clawers.js
```

数据转为原图数据
```
node index_trans.js
```

数据下载
```
node index_download.js
```

> 如果预览图片无法预览的情况，请在爬去的json数据中修改图片链接对应的host地址。
> 如果遇到有疑问的地方，欢迎联系我(QQ:390303304)
